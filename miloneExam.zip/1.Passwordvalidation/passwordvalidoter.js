const fixed_password =prompt("Enter the true password.")
let input_password="soft@568";
if(fixed_password==input_password){
    console.log("You are sucessfully login.")
}
else{
   console.log("Plz enter the currect password. hint- soft@.....")
}
