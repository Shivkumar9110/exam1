let marks=[55,336,256,78,88,747];

let highestMarks=marks.length>0?Math.max(...marks):null
console.log(`In this class hightestmarks is ${highestMarks}`);


















// // Initialize an array with the marks of five students
// const marks = [85, 92, 78, 96, 88];

// // Initialize a variable to keep track of the highest marks
// let highestMarks = marks[0];

// // Iterate through the array to find the highest marks
// for (let i = 1; i < marks.length; i++) {
//   highestMarks = marks[i] > highestMarks ? marks[i] : highestMarks;
// }

// // Display the highest marks to the teacher
// console.log("The highest marks scored by a student is: " + highestMarks);
