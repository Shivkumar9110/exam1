const heading=document.querySelector("#h")



const btn=document.querySelector("button")
 btn.addEventListener("click",fun)
function fun(){
    heading.innerHTML="PW SKILLS"
    heading.style.backgroundColor="yellow"
}