let Name=prompt("Enter the name");

function Name(Name){
    vowal=/[aeiou]/gi;

    const results=Name.match(vowal);
    console.log(results);
    console.log(results.length);
    console.log(results.toLowercase);
}

Name("AMISHA ANAND");



        
  

