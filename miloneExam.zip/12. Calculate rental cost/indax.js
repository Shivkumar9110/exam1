function Economy(day){
    const EconomyRante=4000;
    const totalAmount=day*EconomyRante;
    return console.log(totalAmount);

}

function Luxury(day){
    const LuxuryRante=20000;
    const totalLuxuryAmount=day*LuxuryRante;
    return console.log(totalLuxuryAmount);
}

function Midsizd(day){
    const MidsizdRante=10000;
    const totalMidsizedAmount=day*MidsizdRante;
    return console.log(totalMidsizedAmount);
}


Midsizd(3)
Luxury(32)
Economy(32)





